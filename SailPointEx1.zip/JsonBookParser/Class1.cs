﻿using System;

namespace JsonBookParser
{
    public class JsonParser : IP 
    {
    }
}
